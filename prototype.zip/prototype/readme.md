README for Group 1 Game Prototype 

Note: Our gameplay prototype is best played with a mouse, but a trackpad is workable. Also, the turrets and projectiles implemented are essentially cosmetic (colliding with a bullet does nothing to the player)

Goal: Make it to the swirly door! 

Controls: 

Dash: Press left mouse button, dash on release. Character will dash in direction of the mouse. You will stick to platforms if you hit them. 

Worldshift: Press right mouse button to worldshift. You will hover in midair if you are not currently on a platform (debugging choice, not to be carried forth in real game). 

Reset: R
